name = ("Zhenya")
print(name)
age = 33
print(age)
age = 34
print(age)
is_student = True
print(is_student)